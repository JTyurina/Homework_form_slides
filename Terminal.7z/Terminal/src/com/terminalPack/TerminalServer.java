package com.terminalPack;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


// типы исключений
// ошибка запрашиваемой суммы

public class TerminalServer implements Terminal  {

    private static boolean correctPinEntered;
    private static int currentCashAmount;
    private static boolean accountLocked;
    private static String enteredaccId;
    private static String enteredPin;
    private static int incorrectPinCounter;
    private static  Map<String,Accounts> accMap = new HashMap<>();

    public static int getCurrentCashAmount() {
        return currentCashAmount;
    }

    public static void setCurrentCashAmount(int currentCashAmount) {
        TerminalServer.currentCashAmount = currentCashAmount;
    }

    public static boolean isAccountLocked() {
        return accountLocked;
    }





    public static int getIncorrectPinCounter() {
        return incorrectPinCounter;
    }

    public static void setIncorrectPinCounter(int incorrectPinCounter) {
        if (incorrectPinCounter >= 3)
            setAccountLocked(true);
        else
         TerminalServer.incorrectPinCounter = incorrectPinCounter;
    }


    public static boolean isCorrectPinEntered() {
        return correctPinEntered;
    }

    public static void setCorrectPinEntered(boolean correctPinEntered) {
        TerminalServer.correctPinEntered = correctPinEntered;
    }

    public static boolean getAccountLocked() {
        return accountLocked;
    }

    public static void setAccountLocked(boolean accountLocked) {
        TerminalServer.accountLocked = accountLocked;
    }


    public static String getEnteredaccId() {
        return enteredaccId;
    }


    public static String getEnteredPin() {
        return enteredPin;
    }

    public static void setEnteredPin(String enteredPin) {
        TerminalServer.enteredPin = enteredPin;
    }



    public static Map<String, Accounts> getAccMap() {
        return accMap;
    }

    public static void setAccMap(Map<String, Accounts> accMap) {
        TerminalServer.accMap = accMap;
    }



    public static void setEnteredaccId(String enteredaccId) {
        TerminalServer.enteredaccId = enteredaccId;

    }


    public static void readAccId()
    {
        Scanner sc = new Scanner(System.in);
        setEnteredaccId(sc.nextLine());
    }

    public static void getPin ()
    {
        if (getAccountLocked() == true)
        {
            // кинуть AccountLockedException
        }
        else
        {
            String arrEnteredPin;
            Scanner scanner = new Scanner(System.in);
            // проверка на 4-х  значность пина, непустое значение
            String s = scanner.nextLine();
            setEnteredPin(s.trim());
        }
    }

    public static boolean pinValidation()
    {
        Map<String,Accounts> currAccArr = getAccMap();
        Accounts acc = currAccArr.get(getEnteredaccId());
        if (acc.getPin().equals(getEnteredPin())) {
            setCorrectPinEntered(true);
            return true;
        }
        else {
            setCorrectPinEntered(false);
            setIncorrectPinCounter(getIncorrectPinCounter()+1);
            return false;
        }

    }

    public static void loadTerminalServer()
    {
        setCorrectPinEntered(false);
        setAccountLocked(false);
        setIncorrectPinCounter(0);
        setCurrentCashAmount(10000);
        Accounts acc1 = new Accounts("001",100000,"Linda Goodman","1234");
        Accounts acc2 = new Accounts("002",143200,"Phlipper","5465");
        Accounts acc3 = new Accounts("003",70000,"Kate ","7944");
        Accounts acc4 = new Accounts("004",200000,"Mr. Parkenson","1234");
        Map<String, Accounts> startMap = new HashMap<>();
        startMap.put(acc1.getAccountId(),acc1);
        startMap.put(acc2.getAccountId(),acc2);
        startMap.put(acc3.getAccountId(),acc3);
        startMap.put(acc4.getAccountId(),acc4);
        setAccMap(startMap);   }




    public static void main(String[] args) {

        loadTerminalServer();
        System.out.println("Please enter your card number: ");
        readAccId();
        System.out.print("Please enter pin-code: ");

        getPin();
       if (pinValidation()) {
           System.out.println("Please choose operation to proceed: 1. check balance; 2: deposit money 3: withdraw money 4. Exit");
           int n = 0;
           Scanner sc = new Scanner(System.in);
           TerminalServer ts = new TerminalServer();
           Accounts currAcc = accMap.get(getEnteredaccId());
           while (n != 4){
           n = sc.nextInt();
           switch (n) {
               case 1:
                   System.out.println(ts.checkCurrentBalance(currAcc));
                   break;
               case 2:
                   System.out.print("Enter the sum ");
                   ts.depositMoneyIntoAcc(currAcc, sc.nextInt());
                   System.out.println("Succesful! Your current balance " + currAcc.getBalance());
                   break;
               case 3:
                   System.out.print("Enter the sum ");
                   ts.withdrawMoney(currAcc, sc.nextInt());
                   System.out.println("Succesful! Your current balance " + currAcc.getBalance());
                   break;
               case 4:
                   System.out.print("Please take your card. Good bye.");
                   break;
               default:
                   System.out.println("Invalid operation, try again");
                   break;
                }
           }
       }


    }

    @Override
    public  int checkCurrentBalance(Accounts acc) {
        return acc.getBalance();
    }


    @Override
    public void depositMoneyIntoAcc(Accounts acc, int amount) {

        // исключение некорректных купюр
         acc.setBalance(acc.getBalance() + amount);
        setCurrentCashAmount(getCurrentCashAmount()+amount);

    }

    @Override
    public void withdrawMoney(Accounts acc, int amount) {

        if (getCurrentCashAmount()<amount)
            System.out.print("Терминал не может выдать требуемую сумму");
        if ((amount < 100) || (amount > 100 && amount % 100 != 0))
            System.out.print("Запрашиваемая сумма должна быть кратна 100");
        if (acc.getBalance()<amount)
            System.out.print("Недостаточно средств на счете");

        acc.setBalance(acc.getBalance()-amount);
        setCurrentCashAmount(getCurrentCashAmount()-amount);



    }

    @Override
    public void giveUpCash(int amount) {

    }
}
