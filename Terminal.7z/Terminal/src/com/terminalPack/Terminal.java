package com.terminalPack;

public interface Terminal {
   int checkCurrentBalance(Accounts acc);
   void depositMoneyIntoAcc(Accounts acc, int amount);
   void withdrawMoney(Accounts acc, int amount);
   void giveUpCash(int amount);




}
